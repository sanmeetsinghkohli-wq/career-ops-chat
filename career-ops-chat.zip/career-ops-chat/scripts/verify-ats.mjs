#!/usr/bin/env node

/**
 * verify-ats.mjs — Score a generated CV's ATS-friendliness (deterministic, read-only).
 *
 * The twin of verify-cv-facts.mjs: that gate guards *what* a CV claims; this one
 * guards *whether an ATS can parse it at all*. No LLM, no network, no writes — it
 * reads one CV HTML (the output of `pdf` mode, before PDF rendering) and reports a
 * 0-100 structural score, a letter grade, and a list of concrete, fixable issues.
 *
 * Usage:
 *   node verify-ats.mjs <generated-cv.html>
 *   node verify-ats.mjs <generated-cv.html> --keywords "python,kubernetes,rag"
 *   node verify-ats.mjs <generated-cv.html> --role "Senior Backend Engineer"
 *   node verify-ats.mjs <generated-cv.html> --min-score 80 --json
 *   node verify-ats.mjs --self-test
 *
 * Exit code: 0 when the structural score >= --min-score (default 70) and no
 * critical issue is present; 1 otherwise. Keyword coverage is reported but never
 * changes the structural score (it is advisory and only computed when supplied).
 */

import { readFileSync, statSync } from 'fs';
import { isAbsolute, join, basename } from 'path';
import { fileURLToPath } from 'url';
import { isMainModule } from './lib/is-main-module.mjs'; 
import { asciiFold } from './lib/ascii-fold.mjs';

const DEFAULT_MIN_SCORE = 70;

// Weights sum to 100. Kept explicit so the score is auditable and the self-test
// can pin each check independently.
const WEIGHTS = {
  text: 15,        // real, selectable text present (not image-only / rasterized)
  sections: 20,    // standard, recognizable section headings
  contact: 15,     // email (+ phone) reachable in the body
  layout: 20,      // single-column, no layout tables / multi-column CSS
  images: 10,      // no CV text baked into images
  fonts: 10,       // standard, embeddable fonts
  charset: 5,      // UTF-8 declared
  hidden: 5,       // no hidden text / keyword stuffing
};

const TEXT_MIN_CHARS = 300;      // below this, the CV likely has no real text layer
const TEXT_LOW_WITH_IMG = 800;   // images + this little text ⇒ text probably baked in

// Fonts that ATS PDF text extractors handle reliably (all widely available and
// embeddable). Lowercased. Anything outside this list (and the generic families
// below) is flagged — not because it always fails, but because it is a risk worth
// surfacing. Includes the CJK/Arabic fallbacks the shipped template ships with, so
// a truthful multilingual CV is never penalised.
const ATS_SAFE_FONTS = new Set([
  'arial', 'helvetica', 'helvetica neue', 'liberation sans', 'dejavu sans',
  'calibri', 'candara', 'corbel', 'segoe ui', 'tahoma', 'verdana', 'trebuchet ms',
  'times new roman', 'times', 'georgia', 'cambria', 'garamond', 'book antiqua',
  'palatino', 'palatino linotype', 'lato', 'roboto', 'open sans', 'noto sans',
  'source sans pro', 'pt sans',
  // CJK / Arabic fallbacks used by templates/cv-template.html.
  'hiragino sans', 'hiragino kaku gothic pron', 'yu gothic', 'yugothic',
  'noto sans cjk jp', 'noto sans jp', 'meiryo', 'ms pgothic', 'pingfang sc',
  'hiragino sans gb', 'microsoft yahei', 'noto sans cjk sc', 'noto sans sc',
  'source han sans sc',
  // Korean (html[lang="ko"]) and Traditional Chinese (html[lang="zh-TW"]) — the
  // template declares these stacks unconditionally, so omitting them docked the
  // full fonts weight from every CV, English ones included.
  'apple sd gothic neo', 'malgun gothic', 'noto sans cjk kr', 'noto sans kr',
  'nanum gothic', 'pingfang tc', 'microsoft jhenghei', 'noto sans cjk tc',
  'noto sans tc', 'source han sans tc',
]);

// Generic CSS families — always valid, never "non-standard", so skip them.
const GENERIC_FAMILIES = new Set([
  'sans-serif', 'serif', 'monospace', 'cursive', 'fantasy', 'system-ui',
  'ui-sans-serif', 'ui-serif', 'ui-monospace', 'ui-rounded', 'math', 'emoji',
  '-apple-system', 'blinkmacsystemfont', 'inherit', 'initial', 'unset',
]);

const EMAIL_RE = /[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}/i;
// A run of phone-shaped characters. The length is bounded ({7,24}), so the regex
// itself is ReDoS-safe; the >= 9-digit rule that separates a real number from a
// CV date range like "2019 - 2024" (8 digits) is enforced in hasPhoneNumber, not
// in the pattern (counting digits in a regex without an ambiguous quantifier is
// awkward, so we keep the pattern simple and count afterwards).
const PHONE_CANDIDATE_RE = /\+?\(?\d[\d\s().-]{6,23}\d/g;
const PHONE_MIN_DIGITS = 9;
const PHONE_MAX_CANDIDATES = 50;   // bound the work on adversarial digit-heavy input

/**
 * Collapse all runs of whitespace to single spaces and trim the ends.
 * @param {string} text
 * @returns {string}
 */
function collapse(text) {
  return text.replace(/\s+/g, ' ').trim();
}

// The named entities a generated CV actually carries: the Latin-1 letters an
// accented heading is written with, plus the five markup ones, plus the curly
// quotes a CV written by hand or exported from an editor spells by name.
// Anything else arrives numeric, which is handled generically below.
const NAMED_ENTITIES = {
  nbsp: ' ', amp: '&', lt: '<', gt: '>', quot: '"', apos: "'",
  lsquo: '‘', rsquo: '’', ldquo: '“', rdquo: '”',
  agrave: 'à', aacute: 'á', acirc: 'â', atilde: 'ã', auml: 'ä', aring: 'å', aelig: 'æ',
  ccedil: 'ç', egrave: 'è', eacute: 'é', ecirc: 'ê', euml: 'ë',
  igrave: 'ì', iacute: 'í', icirc: 'î', iuml: 'ï', ntilde: 'ñ',
  ograve: 'ò', oacute: 'ó', ocirc: 'ô', otilde: 'õ', ouml: 'ö', oslash: 'ø',
  ugrave: 'ù', uacute: 'ú', ucirc: 'û', uuml: 'ü', yacute: 'ý', yuml: 'ÿ',
  szlig: 'ß', thorn: 'þ', eth: 'ð', scaron: 'š', zcaron: 'ž', oelig: 'œ',
};

/**
 * Decode the HTML entities a generated CV carries, in ONE pass.
 *
 * Single-pass is what makes this safe. Chained `.replace()` calls have to
 * decode `&amp;` last, or `&amp;lt;` becomes `&lt;` and then `<`, unescaping
 * text that was never an entity. Here each match is replaced once and the
 * replacement is never rescanned, so `&amp;lt;` yields `&lt;` whatever order
 * the table is written in, and the ordering constraint disappears.
 *
 * Case-insensitive for named entities because generated markup is not
 * consistent about it; numeric and hex forms are decoded generically.
 * @param {string} text
 * @returns {string}
 */
function decodeEntities(text) {
  return text.replace(/&(#\d+|#[xX][0-9a-fA-F]+|[a-zA-Z][a-zA-Z0-9]*);/g, (whole, body) => {
    if (body[0] === '#') {
      const code = body[1] === 'x' || body[1] === 'X'
        ? parseInt(body.slice(2), 16)
        : parseInt(body.slice(1), 10);
      // Lone surrogates and out-of-range values are not text; leave them literal.
      if (!Number.isFinite(code) || code < 0 || code > 0x10ffff) return whole;
      if (code >= 0xd800 && code <= 0xdfff) return whole;
      return String.fromCodePoint(code);
    }
    const named = NAMED_ENTITIES[body.toLowerCase()];
    return named === undefined ? whole : named;
  });
}

/**
 * Strip a fragment of inner tags to a plain-text label.
 *
 * Entities are decoded, because this produces the section headings the scorer
 * matches against. `Exp&eacute;rience` reached the matcher as
 * `exp eacute rience` and matched nothing, so a French CV was reported as
 * missing the Experience section it plainly has (#4261).
 */
function stripInline(fragment) {
  return collapse(decodeEntities(fragment.replace(/<[^>]+>/g, ' ')));
}

/**
 * Resolve one `font-family` declaration to the family names it actually asks
 * for, lowercased.
 *
 * A `var(--x)` reference is not a font name, so it must not be reported as a
 * "non-standard font" — but its fallback slot can hold one (`var(--x, Georgia)`),
 * and that name has to survive or a genuinely risky font would hide behind a
 * custom property. So the reference itself is dropped and everything it wrapped
 * is kept. The custom property's *definition* (`--font-family: "Liberation
 * Sans", …`) is scanned separately: the caller's pattern is unanchored, so it
 * matches the declaration and the real faces are still checked.
 * @param {string} declaration The text after `font-family:`, up to the `;`.
 * @returns {string[]} Lowercased family names, empty entries removed.
 */
function parseFontFamilies(declaration) {
  return declaration
    // `var(--name` plus the comma before its fallback; the orphaned `)` that
    // closed the reference is removed with the remaining punctuation below.
    // The name is "any run that is not a separator", not `[\w-]+`: a custom
    // property may be non-ASCII (`--字体`, `--police-caractères`) or carry a
    // CSS escape, and an ASCII-only class stops at the first such character —
    // leaving its tail behind to be reported as a font the CV never named.
    //
    // The separator set is CSS whitespace, spelled out rather than `\s`. The
    // two disagree on U+00A0: JavaScript calls it whitespace, CSS calls it an
    // ordinary identifier character (it is >= U+0080), so `\s` ended the name
    // early on `var(--font family)` and reported `family` as a font.
    .replace(/var\([ \t\n\f\r]*--(?:\\[\s\S]|[^ \t\n\f\r,()])*[ \t\n\f\r]*,?/gi, ' ')
    .split(',')
    // cssTrim, not `.trim()`, for the same JS-vs-CSS disagreement as above but
    // at the ends of the name: `.trim()` also strips U+00A0, so the quoted
    // family `" Arial"` — which is NOT Arial, and resolves to nothing —
    // became `arial`, matched ATS_SAFE_FONTS, and passed silently.
    .map(raw => cssTrim(raw.replace(/['"()]/g, '')).toLowerCase())
    .filter(Boolean);
}

/**
 * Trim CSS whitespace, and only CSS whitespace.
 *
 * `String.prototype.trim()` strips every Unicode space, which is wrong here:
 * CSS whitespace is just these five characters, and everything else it would
 * remove (U+00A0, U+2000-U+200A, U+3000, …) is an ordinary identifier
 * character that belongs to the family name.
 * @param {string} text
 * @returns {string}
 */
function cssTrim(text) {
  return text.replace(/^[ \t\n\f\r]+|[ \t\n\f\r]+$/g, '');
}

/**
 * A font name made safe to print. Anything that renders as blank but is not a
 * plain space — every other Unicode space separator, plus control and format
 * characters — is shown as an escape, so a name flagged *because* of such a
 * character does not read as an ordinary one the reader cannot tell apart.
 * @param {string} name
 * @returns {string}
 */
function describeFontName(name) {
  return name.replace(/[\p{Cc}\p{Cf}\p{Zl}\p{Zp}\p{Zs}]/gu, ch => {
    if (ch === ' ') return ch;
    const code = ch.codePointAt(0);
    // `\uXXXX` is only unambiguous up to U+FFFF. Above it the escape runs to
    // five or six hex digits, and the reader has no way to tell where it ends:
    // U+E0001 printed bare is `1`, which reads as `` followed by a
    // literal "1", naming a different character than the one that was flagged.
    // The braced form is the spelling that terminates itself.
    return code > 0xffff
      ? `\\u{${code.toString(16)}}`
      : `\\u${code.toString(16).padStart(4, '0')}`;
  });
}

/**
 * Remove the regions an ATS text extractor never sees as content — `<script>`
 * and `<style>` bodies and HTML comments — while leaving element tags in place.
 * Used both for visible-text extraction and for link parsing, so a `mailto:`/
 * `tel:` hidden in a comment or script cannot masquerade as reachable contact
 * info.
 * @param {string} html
 * @returns {string}
 */
function stripNonContentRegions(html) {
  return html
    .replace(/<script\b[^>]*>[\s\S]*?<\/script\b[^>]*>/gi, ' ')
    .replace(/<style\b[^>]*>[\s\S]*?<\/style\b[^>]*>/gi, ' ')
    .replace(/<!--[\s\S]*?-->/g, ' ');
}

/**
 * Extract the human-visible text of the CV: drop script/style/comments, unwrap
 * tags, decode the handful of entities that appear in these documents, collapse
 * whitespace. This is what an ATS text extractor is (roughly) left with.
 * @param {string} html
 * @returns {string}
 */
function extractVisibleText(html) {
  // decodeEntities is one pass, so "&amp;lt;" stays the text "&lt;". All of them
  // matter here: build-cv-html writes every apostrophe as &#39;, so a keyword
  // like "Master's degree" read as missing from a CV that says it.
  return collapse(decodeEntities(stripNonContentRegions(html).replace(/<\/?[a-zA-Z][^>]*>/g, ' ')));
}

/**
 * Whether `text` contains something that looks like a real phone number: a
 * bounded phone-shaped run carrying at least PHONE_MIN_DIGITS digits. Only the
 * first PHONE_MAX_CANDIDATES runs are inspected, so pathological digit-heavy
 * input can't blow up. Short numeric spans such as the date range "2019 - 2024"
 * (8 digits) are rejected.
 * @param {string} text
 * @returns {boolean}
 */
function hasPhoneNumber(text) {
  const candidates = text.match(PHONE_CANDIDATE_RE);
  if (!candidates) return false;
  for (const candidate of candidates.slice(0, PHONE_MAX_CANDIDATES)) {
    if ((candidate.match(/\d/g) || []).length >= PHONE_MIN_DIGITS) return true;
  }
  return false;
}

/**
 * Parse actual `<a href>` targets (both quote forms), ignoring script/style/
 * comment regions, and report whether a reachable `mailto:`/`tel:` link exists.
 * This is the fallback for contact info whose visible text isn't the address
 * itself (e.g. `<a href="mailto:…">Email me</a>`), without letting raw-HTML
 * noise satisfy the check.
 * @param {string} html
 * @returns {{email:boolean, phone:boolean}}
 */
function linkContacts(html) {
  let email = false, phone = false;
  for (const m of stripNonContentRegions(html).matchAll(/\bhref\s*=\s*(?:"([^"]*)"|'([^']*)')/gi)) {
    const href = (m[1] ?? m[2]).trim();
    if (/^mailto:.+@.+/i.test(href)) email = true;
    else if (/^tel:.*\d/i.test(href)) phone = true;
  }
  return { email, phone };
}

/**
 * Whether a CSS declaration blob asks for two or more columns, via either
 * `column-count: N` (N >= 2, any number of digits) or the `columns` shorthand
 * (a bare integer token >= 2). Values carrying a unit like `11px` are column
 * widths, not counts, so they are deliberately not treated as multi-column.
 * @param {string} blob
 * @returns {boolean}
 */
function hasMultiColumn(blob) {
  const count = blob.match(/column-count\s*:\s*(\d+)/i);
  if (count && Number(count[1]) >= 2) return true;
  for (const m of blob.matchAll(/\bcolumns\s*:\s*([^;{}]+)/gi)) {
    for (const token of m[1].trim().split(/\s+/)) {
      if (/^\d+$/.test(token) && Number(token) >= 2) return true;
    }
  }
  return false;
}

/**
 * Concatenated text of every `<style>` block.
 * @param {string} html
 * @returns {string}
 */
function extractStyleText(html) {
  return [...html.matchAll(/<style\b[^>]*>([\s\S]*?)<\/style>/gi)].map(m => m[1]).join('\n');
}

/**
 * Every inline `style="…"` / `style='…'` attribute value. Both quote forms are
 * accepted so hidden-text and keyword-stuffing detection cannot be bypassed by
 * switching quote styles.
 * @param {string} html
 * @returns {string[]}
 */
function extractInlineStyles(html) {
  return [...html.matchAll(/style\s*=\s*(?:"([^"]*)"|'([^']*)')/gi)].map(m => m[1] ?? m[2]);
}

// UTF-16 code units for the punctuation `cssDeclarations` reacts to.
const BACKSLASH = 0x5c;
const SLASH = 0x2f;
const STAR = 0x2a;
const SEMICOLON = 0x3b;
const DOUBLE_QUOTE = 0x22;
const SINGLE_QUOTE = 0x27;
const LPAREN = 0x28;
const RPAREN = 0x29;
const LBRACKET = 0x5b;
const RBRACKET = 0x5d;
const LBRACE = 0x7b;
const RBRACE = 0x7d;
const LF = 0x0a;
const CR = 0x0d;
const FF = 0x0c;
// Lowercase ASCII letters, for the `| 32` case fold that finds `url`.
const LOWER_U = 0x75;
const LOWER_R = 0x72;
const LOWER_L = 0x6c;
// CSS whitespace is five characters, not `\s`: U+00A0 is whitespace to
// JavaScript and an ordinary character to CSS.
const isCssSpaceCode = c => c === 0x20 || c === 0x09 || c === LF || c === CR || c === FF;
// What may not immediately precede `url` for it to name the function: a
// character that would make it part of a longer identifier.
const URL_TAIL_BREAK = /[\w\u0080-\uffff-]/;

/**
 * Split an inline style into its declarations the way a browser reads them. A
 * `;` ends a declaration only outside a quoted string, a comment, and any open
 * parentheses, brackets or braces. A backslash escapes the next character (CRLF
 * counts as one), a comment counts as whitespace, and a raw newline ends a
 * string early, as CSS does with a bad string. The body of an unquoted `url(` is
 * raw text up to the first unescaped `)`, so a quote inside it opens nothing.
 * One forward pass, so it stays linear on any input, including an unterminated
 * string, comment, block or url.
 * @param {string} style
 * @returns {string[]}
 */
function cssDeclarations(style) {
  const declarations = [];
  // Characters are compared as UTF-16 code units, not as one-character strings.
  // `style[i]` allocates a fresh string per position; on the 400,000-character
  // run the self-test uses, comparing strings and the `current += c` that
  // followed each one were the bulk of the check's cost (38% of the audit in
  // the loop, 29% in GC, before this rewrite).
  const n = style.length;
  // Open `(`/`[`/`{` as a depth-indexed stack of the code unit that closes each
  // one. `Array#push`/`#pop` on this input cost 22 ms of the audit's 33 ms even
  // though the stack only ever grows, so it is a preallocated buffer with an
  // integer depth instead. Nothing can nest deeper than the string is long.
  const closers = new Uint8Array(n + 1);
  let depth = 0;
  // The declaration being read is a run of characters copied verbatim. It ends
  // only where something must be substituted: a `;` that closes a declaration,
  // or a comment, which collapses to one space. So the scan keeps `start` and
  // pushes slices instead of appending per character. `parts` stays null until
  // the first substitution, and the common no-substitution case is one slice.
  let start = 0;
  let parts = null;
  let quote = 0;
  for (let i = 0; i < n; i++) {
    const c = style.charCodeAt(i);
    if (c === BACKSLASH && i + 1 < n) {
      i += style.charCodeAt(i + 1) === CR && style.charCodeAt(i + 2) === LF ? 2 : 1;
      continue;
    }
    if (quote) {
      if (c === quote || c === LF || c === CR || c === FF) quote = 0;
      continue;
    }
    if (c === SLASH && style.charCodeAt(i + 1) === STAR) {
      const end = style.indexOf('*/', i + 2);
      parts ??= [];
      if (i > start) parts.push(style.slice(start, i));
      parts.push(' ');
      i = end === -1 ? n : end + 1;
      start = i + 1;
      continue;
    }
    if (c === SEMICOLON && depth === 0) {
      if (parts === null) {
        declarations.push(style.slice(start, i));
      } else {
        if (i > start) parts.push(style.slice(start, i));
        declarations.push(parts.join(''));
        parts = null;
      }
      start = i + 1;
      continue;
    }
    // A `(` opening an unquoted `url(`. The three letters before it are
    // compared directly, with `| 32` folding ASCII case: the regex this
    // replaces allocated a four-character slice and entered the regex engine
    // for every open paren, which is the other half of the paren check's cost.
    if (
      c === LPAREN && i >= 3
      && (style.charCodeAt(i - 1) | 32) === LOWER_L
      && (style.charCodeAt(i - 2) | 32) === LOWER_R
      && (style.charCodeAt(i - 3) | 32) === LOWER_U
      && (i - 4 < 0 || !URL_TAIL_BREAK.test(style[i - 4]))
    ) {
      let bodyStart = i + 1;
      while (bodyStart < n && isCssSpaceCode(style.charCodeAt(bodyStart))) bodyStart++;
      const bodyFirst = style.charCodeAt(bodyStart);
      if (bodyFirst !== DOUBLE_QUOTE && bodyFirst !== SINGLE_QUOTE) {
        let end = i + 1;
        while (end < n && style.charCodeAt(end) !== RPAREN) {
          end += style.charCodeAt(end) === BACKSLASH ? 2 : 1;
        }
        // The body is copied through as it stands, so `start` stays where it is
        // and the run simply skips past it.
        i = Math.min(end, n - 1);
        continue;
      }
    }
    if (c === DOUBLE_QUOTE || c === SINGLE_QUOTE) quote = c;
    else if (c === LPAREN) closers[depth++] = RPAREN;
    else if (c === LBRACKET) closers[depth++] = RBRACKET;
    else if (c === LBRACE) closers[depth++] = RBRACE;
    else if (depth > 0 && c === closers[depth - 1]) depth--;
  }
  if (parts === null) {
    declarations.push(style.slice(start));
  } else {
    if (n > start) parts.push(style.slice(start));
    declarations.push(parts.join(''));
  }
  return declarations;
}

/**
 * Candidate section headings: the template's `.section-title` divs plus any
 * generic <h1>–<h6>. Lowercased so downstream matching is case-insensitive.
 * @param {string} html
 * @returns {string[]}
 */
function extractHeadings(html) {
  const out = [];
  for (const m of html.matchAll(/<[^>]*class\s*=\s*"[^"]*\bsection-title\b[^"]*"[^>]*>([\s\S]*?)<\//gi)) {
    out.push(stripInline(m[1]));
  }
  for (const m of html.matchAll(/<h[1-6]\b[^>]*>([\s\S]*?)<\/h[1-6]>/gi)) {
    out.push(stripInline(m[1]));
  }
  // Folded to ASCII, because the patterns matched against these are ASCII by
  // construction. Without it `Compétences` never matches `competenc` and
  // `Expérience` never matches `experience`, so an accented heading reads
  // as a missing section (#4261). Same fix lib/ascii-fold.mjs documents for
  // verify-portals.mjs and providers/_trust-validator.mjs; this was the third
  // instance. The unfolded text is kept too: folding is lossy for scripts with
  // no ASCII base letter (スキル, مهارات), whose patterns must match the original.
  return out
    .flatMap(s => [s.toLowerCase(), asciiFold(s).toLowerCase()])
    .filter(Boolean);
}

/**
 * Build the target keyword set for the advisory coverage check. `--keywords` is
 * split on commas; `--role` is split only on commas, slashes, and the word
 * "and", so a plain title like "Senior Backend Engineer" stays a single phrase
 * matched verbatim against the CV text (it is NOT tokenized into words).
 * @param {string|string[]|undefined} keywords
 * @param {string|undefined} role
 * @returns {string[]} De-duplicated, trimmed keyword phrases (length >= 2).
 */
function normalizeKeywords(keywords, role) {
  const list = [];
  if (Array.isArray(keywords)) list.push(...keywords);
  else if (typeof keywords === 'string') list.push(...keywords.split(','));
  if (role) list.push(...String(role).split(/[,/]|\band\b/i));
  return [...new Set(list.map(k => k.trim()).filter(k => k.length >= 2))];
}

/**
 * Map a 0-100 structural score to a letter grade.
 * @param {number} score
 * @returns {string} One of A, B, C, D, F.
 */
function gradeFor(score) {
  if (score >= 90) return 'A';
  if (score >= 80) return 'B';
  if (score >= 70) return 'C';
  if (score >= 60) return 'D';
  return 'F';
}

// What each check needs in order to be judged (#5940). `structural` is valid on
// an unrendered template: it reads markup and styling. `content` depends on what
// the render payload fills in, so on a template it has no answer. The same two
// scopes templates/ats-rules.yml gives atsLint's rules.
const CHECK_SCOPE = {
  'text-layer': 'content',
  'section-headings': 'content',
  'email-in-header-footer': 'content',
  'email-missing': 'content',
  'phone-missing': 'content',
  'layout-tables': 'structural',
  'multi-column': 'structural',
  'absolute-positioning': 'structural',
  'images-text-baked': 'content',
  'images-non-photo': 'structural',
  'fonts': 'structural',
  'charset': 'structural',
  'hidden-text': 'structural',
};

/**
 * Score a CV HTML string for ATS-friendliness.
 * @param {string} html
 * @param {{keywords?: string|string[], role?: string}} [opts]
 * @returns {{score:number, grade:string, issues:{id:string,scope:'structural'|'content',severity:string,message:string}[], keywordCoverage:null|{total:number,found:number,percent:number,missing:string[]}}}
 */
function auditAts(html, opts = {}) {
  const text = extractVisibleText(html);
  const css = extractStyleText(html);
  const inlineStyles = extractInlineStyles(html);
  // Every place a CSS declaration can live, so equivalent evasions are caught
  // whether the rule sits in a <style> block or an inline style attribute.
  const styleBlobs = [css, ...inlineStyles];
  const issues = [];
  let score = 0;

  const add = (id, severity, message) => issues.push({ id, scope: CHECK_SCOPE[id], severity, message });

  // 1. Real, selectable text.
  if (text.length >= TEXT_MIN_CHARS) {
    score += WEIGHTS.text;
  } else {
    add('text-layer', 'critical', `Very little selectable text (${text.length} chars, expected >= ${TEXT_MIN_CHARS}). The CV may be image-based or rasterized; ATS parsers need a real text layer.`);
  }

  // 2. Standard section headings.
  const headingBlob = extractHeadings(html).join(' | ');
  // Matched against BOTH the raw heading and its ASCII fold (extractHeadings
  // emits each). The Latin terms are therefore written unaccented: `competenc`
  // catches Competences, Competências and Competenze via the fold, so only
  // genuinely different words need their own alternative.
  //
  // career-ops ships evaluation modes for ar, da, de, es, fr, hi, id, it, ja,
  // ko, nl, pl, pt, ru, tr, ua, zh and zh-TW, and before this every one of
  // them failed the gate on a structurally perfect CV. The Skills and
  // experience terms are taken from the `| Skills |` and `| Career history |`
  // rows of each modes/<lang>/README.md rather than invented here; the
  // education terms had no such table and are the ordinary CV heading in each
  // language. Native-speaker corrections welcome, as in #3223.
  // Each term must START a word: `formation` must not be found inside
  // `Information`, nor `formacion` inside `Informacion`. `\b` is ASCII-only, so
  // the boundary is "not preceded by a letter or digit" in any script. Terms
  // stay open on the right (`experien`, `competen`) and the German, Dutch and
  // Danish compounds that put the key word LAST are listed whole.
  const startsWord = (terms) => new RegExp(`(?<![\\p{L}\\p{N}])(?:${terms.join('|')})`, 'u');
  const required = [
    { name: 'Experience', re: startsWord([
      'experience', 'work history', 'employment',          // en
      'experien', 'esperienza',                            // es pt fr (folded); it spells it with an s
      'erfahrung', 'berufserfahrung', 'arbeitserfahrung', 'werdegang', // de: compounds put it last
      'ervaring', 'werkervaring', 'loopbaan',              // nl
      'doswiadczenie', 'przebieg kariery',                 // pl
      'deneyim',                                           // tr
      'erhvervserfaring', 'karriereforlob',                // da
      'riwayat karier', 'pengalaman',                      // id
      'parcours professionnel',                            // fr
      'trayectoria', 'trajetoria',                         // es pt
      'percorso professionale',                            // it
      '職務経歴', '職歴',                                    // ja
      '경력',                                                // ko
      'опыт работы',                                    // ru
      'досвід роботи',                                    // ua
      'الخبرات', 'التاريخ المهني',                        // ar
      'करियर',                                              // hi
      '工作经历', '工作經歷',                                  // zh zh-TW
    ]) },
    { name: 'Education', re: startsWord([
      'education', 'academic',                             // en
      'formation', 'formacion', 'formacao',                // fr es pt
      'ausbildung', 'bildung', 'studium',                  // de
      'istruzione',                                        // it
      'opleiding',                                         // nl
      'wyksztalcenie',                                     // pl
      'egitim',                                            // tr
      'uddannelse',                                        // da
      'pendidikan',                                        // id
      '学歴',                                                // ja
      '학력',                                                // ko
      'образование',                                      // ru
      'освіта',                                              // ua
      'التعليم', 'المؤهلات',                            // ar
      'शिक्षा',                                             // hi
      '教育背景', '學歷',                                    // zh zh-TW
    ]) },
    { name: 'Skills', re: startsWord([
      'skills', 'competen', 'proficienc',                  // en, + es pt fr folded; 'competen' also covers it 'Competenze'
      'kenntnisse', 'fachkenntnisse', 'sprachkenntnisse', 'fahigkeiten', // de
      'habilidades',                                       // es pt
      'vaardigheden',                                      // nl
      'umiejetnosci',                                      // pl
      'beceri',                                            // tr
      'kompetenc', 'kernkompetenc',                        // da + pl/pt variants
      'keahlian',                                          // id
      'スキル',                                              // ja
      '역량', '기술',                                          // ko
      'навыки',                                              // ru
      'навички',                                             // ua
      'مهارات',                                             // ar
      'कौशल',                                               // hi
      '技能', '专业技能', '專業技能',                           // zh zh-TW: 專業技能 does not start with 技能
    ]) },
  ];
  const missing = [];
  for (const s of required) {
    if (s.re.test(headingBlob)) score += 5;
    else missing.push(s.name);
  }
  const bonus = [/summary|profile|objective/, /projects/, /certificat|licenses/]
    .filter(re => re.test(headingBlob)).length;
  score += Math.min(5, bonus * 2);
  if (missing.length) {
    add('section-headings', missing.length >= 2 ? 'critical' : 'warning',
      `Missing standard section heading(s): ${missing.join(', ')}. ATS parsers key off recognizable headings (Experience, Education, Skills).`);
  }

  // 3. Contact info reachable in the body. We strip only *semantic* <header>/
  // <footer> elements: those map to the PDF page header/footer regions ATS
  // extractors routinely discard. The generated template's contact block sits in
  // a plain <div class="header"> in the normal document flow, which parses fine —
  // so it is deliberately NOT stripped (doing so would false-positive every
  // shipped CV). This warning therefore targets hand-authored / alternate HTML
  // that puts contact details inside real <header>/<footer> tags.
  const bodyOnlyHtml = html
    .replace(/<header\b[\s\S]*?<\/header>/gi, ' ')
    .replace(/<footer\b[\s\S]*?<\/footer>/gi, ' ');
  const bodyText = extractVisibleText(bodyOnlyHtml);
  const links = linkContacts(html);
  const bodyLinks = linkContacts(bodyOnlyHtml);
  const hasEmail = EMAIL_RE.test(text) || links.email;
  const emailInBody = EMAIL_RE.test(bodyText) || bodyLinks.email;
  const hasPhone = hasPhoneNumber(text) || links.phone;
  // The 10 email points are contingent on the address being reachable in the
  // body: an email that survives only inside a semantic <header>/<footer> is
  // effectively invisible to the ATS, so it earns no points and is a critical
  // (a bare warning would be ignored by isPass and let the CV pass anyway).
  if (emailInBody) {
    score += 10;
  } else if (hasEmail) {
    add('email-in-header-footer', 'critical', 'Contact email appears only inside a semantic <header>/<footer> element; ATS routinely drop those regions, so the address is effectively unreachable. Move contact details into the main document body.');
  } else {
    add('email-missing', 'critical', 'No email address found. ATS and recruiters need a parseable contact email in the body of the CV.');
  }
  if (hasPhone) score += 5;
  else add('phone-missing', 'info', 'No phone number detected (optional, but many ATS intake forms expect one).');

  // 4. Single-column, no layout tables. `display:table` on a single element does
  // not reorder content, so it is deliberately NOT flagged (the template's
  // definition-list-style certifications block uses it and parses fine).
  let layout = WEIGHTS.layout;
  const tableTags = (html.match(/<table\b/gi) || []).length;
  const multiColumn = styleBlobs.some(hasMultiColumn);
  const absPos = (css.match(/position\s*:\s*absolute/gi) || []).length
    + inlineStyles.filter(s => /position\s*:\s*absolute/i.test(s)).length;
  if (tableTags > 0) {
    layout -= 12;
    add('layout-tables', 'critical', `Found ${tableTags} <table> element(s). Table-based layouts scramble the reading order ATS extractors follow; use a single-column flow.`);
  }
  if (multiColumn) {
    layout -= 8;
    add('multi-column', 'warning', 'CSS multi-column layout detected (column-count/columns). Single-column content parses most reliably.');
  }
  if (absPos > 0) {
    layout -= 4;
    add('absolute-positioning', 'warning', `Found ${absPos} absolutely-positioned element(s); absolute positioning can break ATS reading order.`);
  }
  score += Math.max(0, layout);

  // 5. No CV text baked into images.
  let imageScore = WEIGHTS.images;
  // Scanned on the content regions only: an `<img>` written inside a comment or
  // a `<style>` body renders nothing. The shipped templates/cv-template.html
  // documents its photo slot with the literal text "<img> is emitted" in a CSS
  // comment, which the raw scan counted as a rendered image and docked every CV
  // built from the base template 5 points for.
  const imgs = [...stripNonContentRegions(html).matchAll(/<img\b[^>]*>/gi)].map(m => m[0]);
  const contentImgs = imgs.filter(tag => !/class\s*=\s*(?:"[^"]*\bcv-photo\b[^"]*"|'[^']*\bcv-photo\b[^']*')/i.test(tag));
  if (contentImgs.length > 0 && text.length < TEXT_LOW_WITH_IMG) {
    imageScore = 0;
    add('images-text-baked', 'critical', `Found ${contentImgs.length} content image(s) with little surrounding text (${text.length} chars). Text baked into images is invisible to ATS.`);
  } else if (contentImgs.length > 0) {
    imageScore -= 5;
    add('images-non-photo', 'warning', `Found ${contentImgs.length} non-photo image(s). Ensure no CV text (skills, headings, contact) is baked into images — ATS cannot read image text.`);
  }
  score += Math.max(0, imageScore);

  // 6. Standard, embeddable fonts. Scan both <style> blocks and inline styles so
  // an inline font-family is scored the same as one in a stylesheet.
  const families = new Set();
  for (const blob of styleBlobs) {
    for (const m of blob.matchAll(/font-family\s*:\s*([^;{}]+)/gi)) {
      for (const fam of parseFontFamilies(m[1])) {
        if (!GENERIC_FAMILIES.has(fam)) families.add(fam);
      }
    }
  }
  const unsafeFonts = [...families].filter(f => !ATS_SAFE_FONTS.has(f));
  if (unsafeFonts.length === 0) {
    score += WEIGHTS.fonts;
  } else {
    score += Math.max(0, WEIGHTS.fonts - unsafeFonts.length * 3);
    add('fonts', 'warning', `Non-standard font(s): ${unsafeFonts.map(describeFontName).join(', ')}. Prefer widely-supported, embeddable fonts (Arial, Helvetica, Calibri, Times New Roman, Georgia) for reliable ATS text extraction.`);
  }

  // 7. UTF-8 declared.
  if (/<meta[^>]*charset\s*=\s*["']?\s*utf-8/i.test(html)) {
    score += WEIGHTS.charset;
  } else {
    add('charset', 'warning', 'No <meta charset="utf-8"> declared. Declare UTF-8 so accented characters and symbols survive ATS text extraction.');
  }

  // 8. No hidden text / keyword stuffing. display:none / visibility:hidden /
  // font-size:0 are scanned across both <style> blocks and inline styles.
  const hiddenSignals = [];
  if (styleBlobs.some(s => /display\s*:\s*none/i.test(s))) hiddenSignals.push('display:none');
  if (styleBlobs.some(s => /visibility\s*:\s*hidden/i.test(s))) hiddenSignals.push('visibility:hidden');
  if (styleBlobs.some(s => /font-size\s*:\s*0(?:px|pt|em|rem|%)?\b/i.test(s))) hiddenSignals.push('font-size:0');
  // White text is checked on INLINE styles only, by design: a white color in a
  // <style> block is overwhelmingly legitimate (white-on-colored badges, section
  // headers, the header gradient), so scanning stylesheets for it would flag
  // normal templates. Inline `style="color:#fff"` on a text span is the classic
  // white-on-white stuffing trick and is the reliable signal.
  // The property must start its declaration, so `background-color:#fff` (a
  // visible badge) is not read as `color:#fff`. `-webkit-text-fill-color` paints
  // the glyph fill and overrides `color`, so it counts. A regex over the raw
  // style cannot tell a real declaration from text inside a string or comment,
  // so cssDeclarations splits the style first and each piece is tested alone.
  // Whitespace is CSS's five characters, not `\s`: U+00A0 is whitespace to
  // JavaScript and an ordinary character to CSS, so `\u00A0color:#fff` names a
  // property a browser drops.
  const ws = '[ \\t\\n\\f\\r]*';
  const whiteDeclaration = new RegExp(
    `^${ws}(?:-webkit-text-fill-)?color${ws}:${ws}(?:#fff(?:fff)?\\b|white\\b|rgb\\(${ws}255${ws},${ws}255${ws},${ws}255${ws}\\))`,
    'i',
  );
  if (inlineStyles.some(s => cssDeclarations(s).some(d => whiteDeclaration.test(d)))) {
    hiddenSignals.push('white-on-white text');
  }
  if (hiddenSignals.length === 0) {
    score += WEIGHTS.hidden;
  } else {
    add('hidden-text', 'warning', `Possible hidden text / keyword stuffing (${hiddenSignals.join(', ')}). Hidden keywords are penalised by modern ATS and by recruiters who read the extracted text.`);
  }

  // Optional, advisory keyword coverage — never folded into the structural score.
  let keywordCoverage = null;
  const keywords = normalizeKeywords(opts.keywords, opts.role);
  if (keywords.length) {
    const haystack = text.toLowerCase();
    const found = keywords.filter(k => haystack.includes(k.toLowerCase()));
    const missingKeywords = keywords.filter(k => !haystack.includes(k.toLowerCase()));
    keywordCoverage = {
      total: keywords.length,
      found: found.length,
      percent: Math.round((found.length / keywords.length) * 100),
      missing: missingKeywords,
    };
  }

  score = Math.max(0, Math.min(100, Math.round(score)));
  return { score, grade: gradeFor(score), issues, keywordCoverage };
}

/**
 * Whether a result passes the gate: score at or above the threshold and no
 * critical issue.
 * @param {{score:number, issues:{severity:string}[]}} result
 * @param {number} minScore
 * @returns {boolean}
 */
function isPass(result, minScore) {
  return result.score >= minScore && !result.issues.some(i => i.severity === 'critical');
}

export {
  extractVisibleText,
  extractHeadings,
  auditAts,
  CHECK_SCOPE,
  gradeFor,
  isPass,
  normalizeKeywords,
  DEFAULT_MIN_SCORE,
};

// ── Self-test ────────────────────────────────────────────────────────

/**
 * Build a clean, ATS-friendly CV HTML fixture for the self-test, with hooks to
 * override individual pieces (font, email, charset, sections, extra body) so a
 * single check can be regressed in isolation.
 * @param {{font?:string, email?:string, charset?:string, experience?:string, education?:string, skills?:string, extraBody?:string}} [overrides]
 * @returns {string} A full HTML document.
 */
function buildCleanHtml(overrides = {}) {
  const {
    font = "'Liberation Sans', Arial, sans-serif",
    email = '<a href="mailto:jane@example.com">jane@example.com</a>',
    charset = '<meta charset="UTF-8">',
    experience = '<div class="section"><div class="section-title">Work Experience</div>\n    <p>Staff Engineer, Acme Corp (2020-present). Built and operated the core payments platform,\n    reducing incident rates and improving deployment cadence across multiple engineering teams.</p></div>',
    education = '<div class="section"><div class="section-title">Education</div><p>B.S. Computer Science, State University, 2018. Graduated with honors.</p></div>',
    skills = '<div class="section"><div class="section-title">Skills</div><p>Python, Kubernetes, Docker, PostgreSQL, distributed systems, CI/CD pipelines.</p></div>',
    extraBody = '',
  } = overrides;
  return `<!DOCTYPE html><html lang="en"><head>${charset}
<style>body{font-family:${font};font-size:11px;} .section-title{font-weight:700;text-transform:uppercase;}</style>
</head><body>
  <div class="header">
    <h1>Jane Smith</h1>
    <div class="contact-row">${email} | +1 415 555 0100 | San Francisco, CA</div>
  </div>
  <div class="section"><div class="section-title">Professional Summary</div>
    <p>Senior backend engineer with a decade of experience designing reliable, high-throughput
    distributed systems. Led platform teams delivering resilient services on Kubernetes, with a
    focus on observability, cost efficiency, and clean, well-tested Python codebases used daily
    across the organization.</p></div>
  ${experience}
  <div class="section"><div class="section-title">Projects</div>
    <p>Open-source tracing toolkit adopted by several teams for latency debugging.</p></div>
  ${education}
  ${skills}
  <div class="section"><div class="section-title">Certifications</div>
    <p>Certified Kubernetes Administrator (CNCF), 2022.</p></div>
  ${extraBody}
</body></html>`;
}

/**
 * Run the built-in regression suite over inline fixtures and print a pass/fail
 * summary. Exits with status 1 if any assertion fails.
 * @returns {void}
 */
function runSelfTest() {
  let passed = 0, failed = 0;
  const check = (label, cond) => {
    if (cond) { passed++; } else { failed++; console.log(`  FAIL: ${label}`); }
  };
  const hasIssue = (issues, substr) => issues.some(i => i.message.toLowerCase().includes(substr.toLowerCase()));
  const hasCritical = issues => issues.some(i => i.severity === 'critical');

  // Baseline: a clean, single-column CV with every standard section scores top marks.
  const clean = auditAts(buildCleanHtml());
  check('clean CV scores A (>=90)', clean.score >= 90 && clean.grade === 'A');
  check('clean CV has no critical issues', !hasCritical(clean.issues));
  check('clean CV passes the default gate', isPass(clean, DEFAULT_MIN_SCORE));

  // Missing two required headings ⇒ critical, and both names surfaced.
  const noSections = auditAts(buildCleanHtml({ education: '', skills: '' }));
  check('missing Education+Skills is flagged', hasIssue(noSections.issues, 'Education') && hasIssue(noSections.issues, 'Skills'));
  check('missing two required sections is critical', hasCritical(noSections.issues));

  // A CV in any language career-ops ships a mode for must clear the gate on the
  // same structure an English one clears it on. Before #4261 every one of these
  // was reported as missing all three sections, which is critical, so a
  // structurally perfect non-English CV did not merely score lower: it FAILED.
  {
    const localized = {
      fr: ['Expérience professionnelle', 'Formation', 'Compétences'],
      de: ['Berufserfahrung', 'Ausbildung', 'Kenntnisse'],
      es: ['Experiencia profesional', 'Formación', 'Competencias'],
      it: ['Esperienza professionale', 'Istruzione', 'Competenze'],
      pt: ['Experiência profissional', 'Formação', 'Habilidades'],
      nl: ['Werkervaring', 'Opleiding', 'Vaardigheden'],
      pl: ['Doświadczenie zawodowe', 'Wykształcenie', 'Umiejętności'],
      tr: ['İş deneyimi', 'Eğitim', 'Beceriler'],
      da: ['Erhvervserfaring', 'Uddannelse', 'Kompetencer'],
      id: ['Pengalaman kerja', 'Pendidikan', 'Keahlian'],
      ja: ['職務経歴', '学歴', 'スキル'],
      ko: ['경력', '학력', '역량'],
      ru: ['Опыт работы', 'Образование', 'Навыки'],
      ua: ['Досвід роботи', 'Освіта', 'Навички'],
      ar: ['الخبرات المهنية', 'التعليم', 'مهارات'],
      hi: ['करियर इतिहास', 'शिक्षा', 'कौशल'],
      zh: ['工作经历', '教育背景', '技能'],
      'zh-TW': ['工作經歷', '學歷', '專業技能'],
    };
    const failing = Object.entries(localized)
      .filter(([, [exp, edu, skl]]) => {
        // Each localized heading REPLACES the English one, so the English fallback
        // cannot satisfy the requirement on the localized heading's behalf.
        const cv = auditAts(buildCleanHtml({
          experience: `<div class="section"><div class="section-title">${exp}</div><p>Senior Engineer, Acme, 2019 - 2024.</p></div>`,
          education: `<div class="section"><div class="section-title">${edu}</div><p>B.S. Computer Science, State University, 2018. Graduated with honors.</p></div>`,
          skills: `<div class="section"><div class="section-title">${skl}</div><p>Python, Kubernetes, Docker, PostgreSQL, distributed systems, CI/CD pipelines.</p></div>`,
        }));
        return hasIssue(cv.issues, 'missing standard section');
      })
      .map(([lang]) => lang);
    check(`every localized mode's CV headings are recognized (${Object.keys(localized).length} languages)`,
      failing.length === 0);
  }

  // The entity form of the same heading must read the same as the literal one:
  // `Exp&eacute;rience` reached the matcher as `exp eacute rience`.
  const entityHeading = auditAts(buildCleanHtml({
    education: '<div class="section"><div class="section-title">&Eacute;ducation</div><p>B.S. Computer Science, State University, 2018. Graduated with honors.</p></div>',
  }));
  check('an HTML-entity heading is decoded before matching', !hasIssue(entityHeading.issues, 'missing standard section'));

  // A term must start a word: `Personal Information` contains `formation` and
  // `Informacion personal` contains `formacion`, and neither is an Education
  // heading. A CV with no Education section must still be told so.
  for (const heading of ['Personal Information', 'Informations personnelles', 'Información personal']) {
    const noEdu = auditAts(buildCleanHtml({ education: `<div class="section"><div class="section-title">${heading}</div><p>Based in San Francisco.</p></div>` }));
    check(`"${heading}" does not pass for Education`, hasIssue(noEdu.issues, 'missing standard section'));
  }
  // ...while the compounds that put the key word last are still recognized.
  for (const heading of ['Berufserfahrung', 'Werkervaring', 'Erhvervserfaring']) {
    const compound = auditAts(buildCleanHtml({ experience: `<div class="section"><div class="section-title">${heading}</div><p>Senior Engineer, Acme, 2019 - 2024.</p></div>` }));
    check(`compound heading "${heading}" is recognized for Experience`, !hasIssue(compound.issues, 'missing standard section'));
  }

  // Decoding must not double-unescape: `&amp;lt;` is the literal text "&lt;",
  // not "<". A single pass gives that for free, whatever order the table is in.
  check('decodeEntities does not double-unescape', decodeEntities('&amp;lt;') === '&lt;');
  check('decodeEntities reads decimal and hex forms', decodeEntities('&#233;&#xe9;&#XE9;') === 'ééé');
  // An unknown or malformed entity is text, and must survive untouched.
  check('decodeEntities leaves an unknown entity alone', decodeEntities('&nosuch; &#xZZ; R&D') === '&nosuch; &#xZZ; R&D');

  // Table-based layout ⇒ critical, reading order warning.
  const tableCv = auditAts(
    '<html><head><meta charset="utf-8"></head><body><table><tr><td>' +
    'Experience</td><td>Education</td></tr><tr><td>Skills: Python, Kubernetes and a long ' +
    'description of responsibilities to provide enough selectable text for the parser to read ' +
    'without tripping the low-text image heuristic here.</td><td>jane@example.com</td></tr></table></body></html>'
  );
  check('table layout is flagged', hasIssue(tableCv.issues, '<table>'));
  check('table layout is critical', hasCritical(tableCv.issues));

  // Content image with almost no text ⇒ text-baked-into-image critical.
  const imgCv = auditAts('<html><head><meta charset="utf-8"></head><body><img src="resume.png"><p>Resume</p></body></html>');
  check('content image with low text is flagged', hasIssue(imgCv.issues, 'image'));
  check('content image with low text is critical', hasCritical(imgCv.issues));

  // An <img> that only appears in a comment or a <style> body renders nothing,
  // so it must not be counted. templates/cv-template.html documents its photo
  // slot with the literal text "<img> is emitted" in a CSS comment.
  const documentedImg = auditAts(buildCleanHtml({
    extraBody: '<style>/* with no candidate.photo no <img> is emitted */</style>' +
      '<!-- the photo slot emits an <img src="me.jpg"> when opted in -->',
  }));
  check('an <img> inside a comment or <style> is not counted', !hasIssue(documentedImg.issues, 'image'));

  // …but a real <img> in the body still is — the strip above must not hide one.
  const realImg = auditAts(buildCleanHtml({ extraBody: '<img src="chart.png">' }));
  check('a rendered <img> is still counted', hasIssue(realImg.issues, 'non-photo image'));

  // Non-standard font ⇒ warning naming the font.
  const badFont = auditAts(buildCleanHtml({ font: "'Comic Sans MS', cursive" }));
  check('non-standard font is flagged', hasIssue(badFont.issues, 'comic sans ms'));

  // A var() reference is not a font name and must not be reported as one.
  const varFont = auditAts(buildCleanHtml({ font: 'var(--font-family), Arial, sans-serif' }));
  check('a var() reference is not reported as a font', !hasIssue(varFont.issues, 'non-standard font'));

  // …but a font named in var()'s fallback slot must not hide behind it.
  const varFallback = auditAts(buildCleanHtml({ font: "var(--font-family, 'Comic Sans MS'), sans-serif" }));
  check('a font in a var() fallback is still flagged', hasIssue(varFallback.issues, 'comic sans ms'));

  // A custom property is not restricted to ASCII. An ASCII-only name class
  // stops at the first such character and leaves the tail behind as a "font":
  // `var(--police-caractères)` reported `ères`, and `var(--字体, Arial)`
  // reported `字体` — names the CV never asked for.
  const varNonAscii = auditAts(buildCleanHtml({ font: 'var(--字体, Arial), var(--police-caractères), sans-serif' }));
  check('a non-ASCII custom-property name is consumed whole', !hasIssue(varNonAscii.issues, 'non-standard font'));

  // An escaped character inside the name is part of the name, not a separator.
  const varEscaped = auditAts(buildCleanHtml({ font: 'var(--a\\,b), Arial, sans-serif' }));
  check('an escaped character in a custom-property name is consumed', !hasIssue(varEscaped.issues, 'non-standard font'));

  // U+00A0 is whitespace to JavaScript but an ordinary identifier character to
  // CSS, so a `\s`-based name class ended early here and reported `family`.
  const varNbsp = auditAts(buildCleanHtml({ font: 'var(--font family), Arial, sans-serif' }));
  check('U+00A0 inside a custom-property name is not a separator', !hasIssue(varNbsp.issues, 'non-standard font'));

  // …while real CSS whitespace around the name is still skipped.
  const varSpaced = auditAts(buildCleanHtml({ font: 'var( --font-family ), Arial, sans-serif' }));
  check('CSS whitespace around a custom-property name is skipped', !hasIssue(varSpaced.issues, 'non-standard font'));

  // The same JS-vs-CSS disagreement at the ENDS of a family name. `.trim()`
  // strips U+00A0, so the quoted family " Arial" — which is not Arial and
  // resolves to nothing — trimmed onto the allowlist and passed silently. A
  // false negative: the check said a CV was fine when its font was broken.
  const nbspFont = auditAts(buildCleanHtml({ font: "' Arial', sans-serif" }));
  check('a leading U+00A0 does not trim a family onto the safe list', hasIssue(nbspFont.issues, 'non-standard font'));

  // …and the warning has to name it in a form the reader can act on, or it
  // reports a font that looks exactly like the one they meant to use.
  check('an invisible character in a flagged font is shown as an escape', hasIssue(nbspFont.issues, '\\u00a0arial'));

  // Real CSS whitespace around a family name is still trimmed, so the ordinary
  // `'  Arial  '` spelling gains no warning from the above.
  const paddedFont = auditAts(buildCleanHtml({ font: "'  Arial  ', sans-serif" }));
  check('CSS whitespace around a family name is still trimmed', !hasIssue(paddedFont.issues, 'non-standard font'));

  // A font that was already flagged must now be named correctly rather than
  // under the plain name its invisible prefix trimmed onto.
  const nbspUnsafe = auditAts(buildCleanHtml({ font: "' Comic Sans MS', sans-serif" }));
  check('a flagged font keeps its real name', hasIssue(nbspUnsafe.issues, '\\u00a0comic sans ms'));

  // Above the BMP a bare `\uXXXXX` does not say where it ends: U+E0001 printed
  // as `1` reads as `` then "1", which is a different character.
  const astralFont = auditAts(buildCleanHtml({ font: "'\u{E0001}Arial', sans-serif" }));
  check('a format character above the BMP is escaped in braces', hasIssue(astralFont.issues, '\\u{e0001}arial'));

  // …and the BMP spelling stays the familiar four-digit one, so the common
  // case is not churned for the sake of the rare one.
  check('a BMP character keeps the bare four-digit escape', hasIssue(nbspFont.issues, '\\u00a0arial'));

  // The Korean and Traditional Chinese stacks the template declares
  // unconditionally must not penalise a CV that never renders them.
  const cjkFallbacks = auditAts(buildCleanHtml({
    font: "var(--font-family), 'Apple SD Gothic Neo', 'Malgun Gothic', 'Noto Sans CJK KR', " +
      "'Noto Sans KR', 'Nanum Gothic', 'PingFang TC', 'Microsoft JhengHei', " +
      "'Noto Sans CJK TC', 'Noto Sans TC', 'Source Han Sans TC', sans-serif",
  }));
  check('Korean/Traditional Chinese fallbacks are not flagged', !hasIssue(cjkFallbacks.issues, 'non-standard font'));

  // No email anywhere ⇒ critical.
  const noEmail = auditAts(buildCleanHtml({ email: 'San Francisco' }));
  check('missing email is flagged', hasIssue(noEmail.issues, 'no email'));
  check('missing email is critical', hasCritical(noEmail.issues));

  // Hidden white-on-white text ⇒ stuffing warning.
  const hidden = auditAts(buildCleanHtml({ extraBody: '<span style="color:#ffffff">python kubernetes aws rust golang</span>' }));
  check('hidden white text is flagged', hasIssue(hidden.issues, 'hidden text'));

  // Single-quoted inline styles must not bypass hidden-text detection.
  const hiddenSingleQuote = auditAts(buildCleanHtml({ extraBody: "<span style='color:#ffffff'>python rust golang aws terraform</span>" }));
  check('single-quoted white text is flagged', hasIssue(hiddenSingleQuote.issues, 'hidden text'));

  // A white VALUE on a property that merely ends in `color` is visible text
  // (a badge, a bordered callout), not white-on-white stuffing. `color:#fff`
  // is a substring of `background-color:#fff`, so the signal is anchored on
  // the start of a declaration. This mirrors atsLint in cv-templates.mjs.
  for (const [label, style] of [
    ['white background-color with dark text', 'background-color:#fff; color:#111'],
    ['named white background-color with dark text', 'background-color:white;color:#222'],
    ['white border-color with dark text', 'border-color:#fff; color:#000'],
  ]) {
    const visible = auditAts(buildCleanHtml({ extraBody: `<span style="${style}">Senior engineer</span>` }));
    check(`${label} is not flagged as hidden text`, !hasIssue(visible.issues, 'hidden text'));
  }
  // U+00A0 is whitespace to JavaScript's \s but an ordinary character to CSS, so
  // a non-breaking space in a declaration makes a browser drop it. Chromium
  // paints none of these white; the form-feed and space-padded controls it does.
  for (const [label, style] of [
    ['a no-break space before the property', '\u00A0color:#fff'],
    ['a no-break space after the colon', 'color:\u00A0#fff'],
    ['a no-break space before the colon', 'color\u00A0:#fff'],
    ['a no-break space inside rgb()', 'color:rgb(255,\u00A0255,255)'],
  ]) {
    const inert = auditAts(buildCleanHtml({ extraBody: `<span style="${style}">Senior engineer</span>` }));
    check(`${label} is not flagged as hidden text`, !hasIssue(inert.issues, 'hidden text'));
  }
  for (const [label, style] of [
    ['a form feed before the property', '\fcolor:#fff'],
    ['spaces around the colon', 'color : #fff'],
    ['spaces inside rgb()', 'color:rgb( 255 , 255 , 255 )'],
  ]) {
    const stuffed = auditAts(buildCleanHtml({ extraBody: `<span style="${style}">python kubernetes aws rust golang</span>` }));
    check(`${label} still flags as hidden text`, hasIssue(stuffed.issues, 'hidden text'));
  }
  // The anchor must not disable the detector: genuine white text still flags,
  // including after another declaration and when no declaration precedes it.
  for (const [label, style] of [
    ['bare color:#fff', 'color:#fff'],
    ['color:#ffffff after another declaration', 'font-weight:bold;color:#ffffff'],
    ['color:white after a space', 'font-weight:bold; color:white'],
    ['color:rgb(255,255,255)', 'color:rgb(255, 255, 255)'],
  ]) {
    const stuffed = auditAts(buildCleanHtml({ extraBody: `<span style="${style}">python kubernetes aws rust golang</span>` }));
    check(`${label} is still flagged as hidden text`, hasIssue(stuffed.issues, 'hidden text'));
  }
  // -webkit-text-fill-color paints the glyph fill and overrides `color`, so a
  // white fill is white text. A CSS comment is whitespace to a browser, so a
  // declaration behind one is still a declaration.
  for (const [label, style] of [
    ['-webkit-text-fill-color:#fff over dark color', '-webkit-text-fill-color:#fff;color:#111'],
    ['-webkit-text-fill-color:white after another declaration', 'font-weight:bold;-webkit-text-fill-color:white;color:#111'],
    ['color:#fff after a comment following a declaration', 'background:red;/**/color:#fff'],
    ['color:#fff after a leading comment', '/**/color:#fff'],
  ]) {
    const stuffed = auditAts(buildCleanHtml({ extraBody: `<span style="${style}">python kubernetes aws rust golang</span>` }));
    check(`${label} is flagged as hidden text`, hasIssue(stuffed.issues, 'hidden text'));
  }
  // A comment inside a non-color declaration must not create a false positive.
  const commentedBackground = auditAts(buildCleanHtml({ extraBody: '<span style="background-color:/**/#fff;color:#111">Senior engineer</span>' }));
  check('white background-color with an inner comment is not flagged as hidden text', !hasIssue(commentedBackground.issues, 'hidden text'));
  // A comment splits a CSS identifier in two, so `col/**/or` is not `color`. A
  // browser drops that declaration, so it must not read as white text.
  const splitIdent = auditAts(buildCleanHtml({ extraBody: '<span style="col/**/or:#fff">Senior engineer</span>' }));
  check('a comment splitting the property name is not flagged as hidden text', !hasIssue(splitIdent.issues, 'hidden text'));
  // Comment markers inside a quoted value belong to the string, not a comment.
  // Reading them as one would delete the real declaration that sits between.
  const quotedMarkers = auditAts(buildCleanHtml({ extraBody: `<span style="font-family:'/*';color:#fff;font-family:'*/'">python kubernetes aws rust golang</span>` }));
  check('comment markers inside quoted values do not hide a real white declaration', hasIssue(quotedMarkers.issues, 'hidden text'));
  // A quoted value can hold text that looks like a declaration. Here the real
  // color is #111; the white one is inside a string, and the browser ignores it.
  const quotedFake = auditAts(buildCleanHtml({ extraBody: `<span style="font-family:';color/**/:#fff';color:#111">Senior engineer</span>` }));
  check('a white declaration inside a quoted value is not flagged as hidden text', !hasIssue(quotedFake.issues, 'hidden text'));
  // The comment pattern must not match across a `*/`. If it could, a run of
  // comments splits exponentially many ways, and a style that fails to match
  // at its end backtracks through every one of them.
  const manyComments = `<span style=";${'/**/'.repeat(30)}colour:#fff">Senior engineer</span>`;
  const auditStarted = performance.now();
  auditAts(buildCleanHtml({ extraBody: manyComments }));
  check('a long run of comments does not backtrack catastrophically', performance.now() - auditStarted < 1000);
  // Looking back for `url` on every open paren must not flatten the text built
  // so far each time: that made a long run of `(` quadratic, seconds at 400k.
  const manyParens = `<span style="${'('.repeat(400000)}">Senior engineer</span>`;
  const parensStarted = performance.now();
  auditAts(buildCleanHtml({ extraBody: manyParens }));
  check('a long run of open parentheses stays linear', performance.now() - parensStarted < 1000);
  // An unterminated comment must not be rescanned from every semicolon. That
  // made a long `;/*;/*` run quadratic: seconds at 100k characters.
  const unterminated = `<span style="${';/*'.repeat(33334)}colour:#fff">Senior engineer</span>`;
  const unterminatedStarted = performance.now();
  auditAts(buildCleanHtml({ extraBody: unterminated }));
  check('a long run of unterminated comments stays linear', performance.now() - unterminatedStarted < 1000);
  // A semicolon inside a string or a comment does not end a declaration, so
  // white text written inside either one is never applied by the browser.
  for (const [label, style] of [
    ['inside a quoted value', `--x:'/*;color:#fff';color:#111`],
    ['inside a comment', 'color:#111;/*;color:#fff*/'],
  ]) {
    const inert = auditAts(buildCleanHtml({ extraBody: `<span style="${style}">Senior engineer</span>` }));
    check(`white text ${label} is not flagged as hidden text`, !hasIssue(inert.issues, 'hidden text'));
  }
  // An unterminated string runs to the end, and an escaped `;` is part of a
  // value. Either way the white declaration after it is never applied.
  for (const [label, style] of [
    ['after an unterminated string', `font-family:'abc;color:#fff`],
    ['after an escaped semicolon', 'a:b\\;color:#fff'],
  ]) {
    const swallowed = auditAts(buildCleanHtml({ extraBody: `<span style="${style}">Senior engineer</span>` }));
    check(`white text ${label} is not flagged as hidden text`, !hasIssue(swallowed.issues, 'hidden text'));
  }
  // A raw newline ends a quoted string early: CSS reads it as a bad string, so
  // the declaration after it is real. Every CSS newline form counts.
  for (const [label, nl] of [['LF', '\n'], ['CR', '\r'], ['FF', '\f'], ['CRLF', '\r\n']]) {
    const broken = auditAts(buildCleanHtml({ extraBody: `<span style="font-family:'x${nl};color:white">python kubernetes aws rust golang</span>` }));
    check(`white text after a string broken by ${label} is flagged as hidden text`, hasIssue(broken.issues, 'hidden text'));
  }
  // An escaped newline inside a string is a continuation, and CRLF is one
  // newline, so the backslash takes both characters. Taking only the CR left
  // the LF to end the string early, and the quote after it opened a new one
  // that swallowed the real declaration behind it.
  for (const [label, nl] of [['LF', '\n'], ['CR', '\r'], ['FF', '\f'], ['CRLF', '\r\n']]) {
    const continued = auditAts(buildCleanHtml({ extraBody: `<span style="font-family:'x\\${nl}';color:white">python kubernetes aws rust golang</span>` }));
    check(`white text after a string continued over an escaped ${label} is flagged as hidden text`, hasIssue(continued.issues, 'hidden text'));
  }
  // A style holding a double quote has to sit in a single-quoted attribute,
  // or the attribute ends at that quote and the CSS under test is never seen.
  const attrQuote = style => (style.includes('"') ? "'" : '"');
  // The body of an unquoted url() is raw text up to the first `)`, so a quote
  // inside it does not open a string. A browser treats that as a bad url and
  // resumes after the `)`; reading the quote as a string swallowed everything
  // after it, white declaration included.
  for (const [label, style] of [
    ['a double quote in an unquoted url()', 'background:url(foo";x);color:white'],
    ['a single quote in an unquoted url()', "background:url(foo';x);color:white"],
    ['an uppercase URL() with a quote in it', 'background:URL(foo";x);color:white'],
    ['an escaped paren inside an unquoted url()', 'background:url(a\\);b";x);color:white'],
    ['a stray open paren in an unquoted url()', 'background:url(a(b";x);color:white'],
  ]) {
    const badUrl = auditAts(buildCleanHtml({ extraBody: `<span style=${attrQuote(style)}${style}${attrQuote(style)}>python kubernetes aws rust golang</span>` }));
    check(`white text after ${label} is flagged as hidden text`, hasIssue(badUrl.issues, 'hidden text'));
  }
  // The same raw-text rule must not release a `;` that really is inside the
  // url, nor treat a quoted url() argument or a lookalike name as unquoted.
  for (const [label, style] of [
    ['inside an unquoted url()', 'background:url(data:x;color:white)'],
    ['inside a quoted url()', `background:url("data:x;color:white")`],
    ['inside an unterminated unquoted url()', 'background:url(foo;color:white'],
    ['after a function whose name only ends in url', 'background:myurl(foo";x);color:white'],
  ]) {
    const inertUrl = auditAts(buildCleanHtml({ extraBody: `<span style=${attrQuote(style)}${style}${attrQuote(style)}>Senior engineer</span>` }));
    check(`white text ${label} is not flagged as hidden text`, !hasIssue(inertUrl.issues, 'hidden text'));
  }
  // url() with whitespace and a quote after the paren is a normal function
  // with a string argument, not an unquoted url. The `)` inside the string is
  // what tells the two readings apart: read as raw text, the url would end at
  // that `)` and the rest of the string would open a new one.
  const spacedQuoted = auditAts(buildCleanHtml({ extraBody: `<span style="background:url(  'a)b'  );color:white">python kubernetes aws rust golang</span>` }));
  check('white text after a quoted url() argument with leading space is flagged as hidden text', hasIssue(spacedQuoted.issues, 'hidden text'));
  // A `;` inside parentheses or brackets belongs to that value, not to the
  // declaration list, so it cannot start a new declaration.
  for (const [label, style] of [
    ['inside url()', 'background:url(data:x;color:white)'],
    ['inside a function', 'background:foo(abc;color:white)'],
    ['inside brackets', 'grid-template-areas:[a;color:white]'],
  ]) {
    const nested = auditAts(buildCleanHtml({ extraBody: `<span style="${style}">Senior engineer</span>` }));
    check(`white text ${label} is not flagged as hidden text`, !hasIssue(nested.issues, 'hidden text'));
  }
  // A comment may sit on either side of the colon, and the declaration applies.
  for (const [label, style] of [
    ['a comment before the colon', 'color/**/:#fff'],
    ['a comment after the colon', 'color:/**/#fff'],
  ]) {
    const commented = auditAts(buildCleanHtml({ extraBody: `<span style="${style}">python kubernetes aws rust golang</span>` }));
    check(`white text with ${label} is still flagged as hidden text`, hasIssue(commented.issues, 'hidden text'));
  }

  // Inline font-family is scored the same as a stylesheet font-family.
  const inlineFont = auditAts(buildCleanHtml({ extraBody: '<p style="font-family:\'Comic Sans MS\'">extra line</p>' }));
  check('inline non-standard font is flagged', hasIssue(inlineFont.issues, 'comic sans ms'));

  // PHONE_RE must not treat a bare year range as a phone number.
  const yearRangeOnly = auditAts(
    '<html><head><meta charset="utf-8"></head><body>' +
    '<div class="section-title">Work Experience</div><div class="section-title">Education</div>' +
    '<div class="section-title">Skills</div>' +
    '<p>Reach me at jane@example.com. Employed 2019 - 2024 building reliable, high-throughput ' +
    'distributed systems on Kubernetes, with clean, well-tested Python services used daily across ' +
    'the whole organization and its many engineering teams.</p></body></html>'
  );
  check('a bare year range is not counted as a phone', hasIssue(yearRangeOnly.issues, 'no phone number'));
  check('a real phone number is detected', !hasIssue(auditAts(buildCleanHtml()).issues, 'no phone number'));

  // Email only inside a semantic <header> is unreachable ⇒ critical (a warning
  // alone would be ignored by isPass and let the CV pass anyway).
  const headerOnlyEmail = auditAts(
    '<html><head><meta charset="utf-8"></head><body>' +
    '<header><div>jane@example.com | +1 415 555 0100</div></header>' +
    '<div class="section-title">Work Experience</div>' +
    '<div class="section-title">Education</div><div class="section-title">Skills</div>' +
    '<p>Built and operated reliable, high-throughput distributed systems on Kubernetes with ' +
    'clean, well-tested Python services used daily across many engineering teams, focusing on ' +
    'observability, cost efficiency, and resilient delivery pipelines shipped safely to ' +
    'production several times per day for years.</p></body></html>'
  );
  check('email only in a semantic <header> is critical', hasCritical(headerOnlyEmail.issues) && hasIssue(headerOnlyEmail.issues, '<header>'));
  check('email only in a semantic <header> fails the gate', !isPass(headerOnlyEmail, DEFAULT_MIN_SCORE));

  // A mailto:/tel: buried in a comment or <script> must NOT satisfy detection…
  const buriedContact = auditAts(
    '<html><head><meta charset="utf-8"></head><body>' +
    '<!-- <a href="mailto:ghost@example.com">x</a> --><script>var t = "tel:+15551234567";</script>' +
    '<div class="section-title">Work Experience</div><div class="section-title">Education</div>' +
    '<div class="section-title">Skills</div>' +
    '<p>Built and operated reliable, high-throughput distributed systems on Kubernetes with clean, ' +
    'well-tested Python services used daily across many engineering teams for years and years now.</p>' +
    '</body></html>'
  );
  check('mailto/tel in a comment or script is not a reachable email', hasIssue(buriedContact.issues, 'no email'));

  // …but a mailto: href whose visible text is not the address itself does count.
  const mailtoHrefOnly = auditAts(buildCleanHtml({ email: '<a href="mailto:jane@example.com">Email me</a>' }));
  check('mailto: href with non-email link text still counts', !hasIssue(mailtoHrefOnly.issues, 'no email'));

  // Multi-column layout is flagged for two-digit counts and for inline styles.
  const twoDigitCols = auditAts(buildCleanHtml({ extraBody: '<style>.grid{column-count:10;}</style>' }));
  check('two-digit column-count is flagged', hasIssue(twoDigitCols.issues, 'multi-column'));
  const inlineCols = auditAts(buildCleanHtml({ extraBody: '<div style="columns: 2">a b</div>' }));
  check('inline columns shorthand is flagged', hasIssue(inlineCols.issues, 'multi-column'));

  // Keyword coverage is opt-in and never touches the structural score.
  const withKeywords = auditAts(buildCleanHtml(), { keywords: 'python, kubernetes, rust' });
  check('keyword coverage computed when supplied', withKeywords.keywordCoverage !== null);
  check('keyword coverage percent is correct (2/3)', withKeywords.keywordCoverage.percent === 67);
  check('missing keyword is listed', withKeywords.keywordCoverage.missing.includes('rust'));
  check('supplying keywords does not change the score', withKeywords.score === clean.score);
  check('no keyword coverage without --keywords/--role', clean.keywordCoverage === null);

  console.log(`\nverify-ats self-test: ${passed} passed, ${failed} failed`);
  if (failed > 0) process.exit(1);
}

// ── CLI ──────────────────────────────────────────────────────────────

/**
 * Print a human-readable ATS report (score, grade, issues, keyword coverage,
 * pass/fail) to stdout.
 * @param {{score:number, grade:string, issues:{severity:string,message:string}[], keywordCoverage:null|{found:number,total:number,percent:number,missing:string[]}}} result
 * @param {string} file - Display name for the checked file.
 * @param {number} minScore
 * @returns {void}
 */
function printHuman(result, file, minScore) {
  const pass = isPass(result, minScore);
  console.log(`ATS check: ${file}`);
  console.log(`Score: ${result.score}/100 (${result.grade})   Threshold: ${minScore}`);
  if (result.issues.length) {
    console.log('\nIssues:');
    for (const i of result.issues) console.log(`  [${i.severity}] ${i.message}`);
  }
  if (result.keywordCoverage) {
    const k = result.keywordCoverage;
    console.log(`\nKeyword coverage: ${k.found}/${k.total} (${k.percent}%)`);
    if (k.missing.length) console.log(`  Missing: ${k.missing.join(', ')}`);
  }
  console.log(`\nATS check ${pass ? 'passed' : 'failed'}: ${file}`);
  if (!pass) {
    console.log('Fix the critical/warning items above, or lower the bar with --min-score if you accept the risk.');
  }
}

if (isMainModule(import.meta.url)) {
  const args = process.argv.slice(2);

  if (args.includes('--self-test')) {
    runSelfTest();
  } else {
    let targetArg = '';
    let keywords = '';
    let role = '';
    let minScore = DEFAULT_MIN_SCORE;
    let asJson = false;

    // A value is "missing" if there is no next token or the next token is itself
    // an option flag (e.g. `--keywords --json` must error, not swallow --json).
    const missingValue = (t) => t === undefined || t.startsWith('-');

    for (let i = 0; i < args.length; i++) {
      const arg = args[i];
      if (arg === '--keywords') {
        if (missingValue(args[i + 1])) { console.error('ERROR: --keywords requires a comma-separated list'); process.exit(1); }
        keywords = args[++i];
      } else if (arg === '--role') {
        if (missingValue(args[i + 1])) { console.error('ERROR: --role requires a value'); process.exit(1); }
        role = args[++i];
      } else if (arg === '--min-score') {
        if (!args[i + 1]) { console.error('ERROR: --min-score requires a number'); process.exit(1); }
        minScore = Number(args[++i]);
        if (!Number.isFinite(minScore) || minScore < 0 || minScore > 100) {
          console.error('ERROR: --min-score must be a number between 0 and 100');
          process.exit(1);
        }
      } else if (arg === '--json') {
        asJson = true;
      } else if (arg === '--help' || arg === '-h') {
        // handled below
      } else if (arg.startsWith('--')) {
        console.error(`ERROR: unknown option: ${arg}`);
        process.exit(1);
      } else if (!targetArg) {
        targetArg = arg;
      } else {
        console.error(`ERROR: unexpected extra positional argument: ${arg}`);
        process.exit(1);
      }
    }

    const helpRequested = args.includes('--help') || args.includes('-h');
    if (!targetArg || helpRequested) {
      console.log(`Usage: node verify-ats.mjs <generated-cv.html> [--keywords "a,b,c"] [--role "..."] [--min-score N] [--json]

Scores a generated CV's HTML for ATS parseability (0-100 + letter grade) and lists
concrete, fixable issues. Deterministic, read-only. Exits 0 when score >= --min-score
(default ${DEFAULT_MIN_SCORE}) and no critical issue is present, else 1.

Keyword coverage (--keywords / --role) is advisory and never changes the score.`);
      // An explicit --help is a success; a missing target is a usage error.
      process.exit(helpRequested ? 0 : 1);
    }

    const targetPath = isAbsolute(targetArg) ? targetArg : join(process.cwd(), targetArg);
    let html;
    try {
      if (!statSync(targetPath).isFile()) throw new Error('not a regular file');
      html = readFileSync(targetPath, 'utf-8');
    } catch (err) {
      console.error(`ERROR: cannot read target file: ${targetArg} (${err.code || err.message})`);
      process.exit(1);
    }
    const result = auditAts(html, { keywords, role });
    const pass = isPass(result, minScore);
    const file = basename(targetPath);

    if (asJson) {
      console.log(JSON.stringify({ file, pass, minScore, ...result }, null, 2));
    } else {
      printHuman(result, file, minScore);
    }
    // Set exitCode (don't process.exit) so buffered stdout drains before exit.
    process.exitCode = pass ? 0 : 1;
  }
}
